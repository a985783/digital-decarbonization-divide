---
title: "The Digital Decarbonization Divide: Asymmetric Effects of ICT on CO₂ Emissions Across Socio-economic Capacity"
author:
  - name: Qingsong Cui
    affiliation: Independent Researcher
date: "January 21, 2026"
jel_codes: "C14, C23, O33, Q56"
abstract: |
  Using a Causal Forest framework with 2,000 trees on a balanced panel of 40 economies (2000-2023, N=960), we uncover striking **structural heterogeneity** in the climate impact of digital transformation. We find statistically strong evidence of heterogeneity with respect to economic development in a clustered interaction-DML test (p < 0.001). Causal-forest estimates further suggest that the marginal effect becomes more negative at higher levels of socio-economic capacity, though pointwise intervals are reported as descriptive and are not cluster-adjusted. The mean estimated marginal effect (mean CATE) is modest (≈ −0.02 metric tons per 1 p.p.), but the marginal effect ranges from −0.10 to +0.04 metric tons per capita. We find that 25.3% of pointwise estimates have confidence intervals excluding zero (uncorrected for multiple testing). Policy implication: Our results suggest that digital policies may be complementary to capacity-building rather than acting as a stand-alone decarbonization lever.

keywords: "Causal Forest, Double Machine Learning, Heterogeneous Treatment Effects, Socio-economic Capacity, Economic Development, Institutional Quality"
---

# 1. Introduction

The potential of the digital economy to drive environmental sustainability is a subject of intense debate. While digitalization offers pathways to dematerialization and efficiency, it also entails a growing energy footprint from data centers, network infrastructure, and electronic devices (Lange et al., 2020). Previous empirical studies have produced mixed results, often constrained by small sample sizes, omitted variable bias, and linear functional form assumptions (Salahuddin & Alam, 2016).

**This paper proposes a new perspective: the "Digital Decarbonization Divide."** Rather than asking whether ICT *on average* reduces emissions, we investigate *when* and *where* digital transformation delivers climate benefits. Our key insight is that the ICT–emissions relationship is fundamentally heterogeneous, depending on broad socio-economic capacity, including economic development and institutional quality.

## 1.1 Related Literature

The relationship between ICT and carbon emissions has been examined through multiple theoretical lenses. The *dematerialization hypothesis* posits that digital technologies substitute for physical products and travel, reducing material throughput and emissions (Berkhout & Hertin, 2000). Conversely, the *rebound effect hypothesis* suggests that efficiency gains from ICT are offset by increased consumption (Gossart, 2015).

Empirical evidence remains mixed. Salahuddin & Alam (2016) find a positive relationship between ICT and emissions in OECD countries. Danish et al. (2018) report a negative effect in emerging economies. Recent meta-analyses highlight that results are highly sensitive to sample selection, variable definitions, and estimation methods (Lange et al., 2020).

A critical methodological gap is the assumption of homogeneous treatment effects. Traditional panel models estimate an *average* effect, masking potentially important heterogeneity. **This paper addresses this gap by employing Causal Forest DML (Athey & Wager, 2019), which estimates Conditional Average Treatment Effects (CATE) for each observation.**

## 1.2 Contributions

This study advances the literature in three ways:

1. **Discovery of the "Digital Decarbonization Divide"**: We document that ICT's climate impact varies systematically with socio-economic capacity. The effect ranges from strongly negative (−0.10 metric tons) to mildly positive (+0.04 metric tons).

2. **Causal Forest methodology**: We implement CausalForestDML with 2,000 trees, XGBoost first-stage models, and proper inference intervals—a significant methodological upgrade from linear DML.

3. **Policy-relevant heterogeneity**: Our results identify which countries benefit from digital decarbonization and which face potential "digital rebound effects," enabling targeted policy recommendations.

## 1.3 Key Findings

Our Causal Forest analysis reveals:

| Finding | Value |
|---------|-------|
| Pointwise significant estimates | 25.3% (uncorrected) |
| CATE range | −0.10 to +0.04 metric tons/capita |
| Negative point estimates (proportion) | 95.7% of observations |
| Descriptive association: $\tau(x)$ vs GDP | r = −0.55 |
| Descriptive association: $\tau(x)$ vs Institution | r = −0.40 |

The remainder of this paper is organized as follows. Section 2 describes the data. Section 3 presents the methodology. Section 4 reports results. Section 5 discusses implications. Section 6 concludes.

---

# 2. Data and Sample Construction

## 2.1 Data Source

We retrieve data from two World Bank databases: the World Development Indicators (WDI) and the Worldwide Governance Indicators (WGI). The WDI provides 60 economic, social, and environmental variables, while the WGI offers six dimensions of institutional quality.

## 2.2 Sample Selection

Our sample comprises a focused group of 40 major economies (20 OECD, 20 non-OECD) observed from 2000 to 2023. We employ MICE (Multiple Imputation by Chained Equations) to impute missing values in the dataset, constructing a balanced panel to maximize information retention. This process yields:
- A balanced panel of 40 countries over 24 years.
- Total observations N = 960 (40 × 24).

## 2.3 Variables

### Table 1: Variable Definitions
| Variable | Definition | Source |
| :--- | :--- | :--- |
| **Core Variables** | | |
| CO₂ Emissions | Per capita (metric tons) | WDI |
| ICT Service Exports | % of service exports | WDI |
| **Institutional Quality (WGI)** | | |
| Control of Corruption | Perceptions of public power for private gain | WGI |
| Rule of Law | Confidence in societal rules | WGI |
| Government Effectiveness | Quality of public services | WGI |
| Regulatory Quality | Private sector development capacity | WGI |
| **Control Variables (57 total)** | | |
| GDP per capita | Constant 2015 US$ | WDI |
| Energy Use | Kg oil equivalent per capita | WDI |
| Renewable Energy | % of total energy consumption | WDI |
| Urban Population | % of total population | WDI |
| Internet Users | % of population | WDI |

## 2.4 Descriptive Statistics

### Table 2: Descriptive Statistics (N = 960)
| Variable | Mean | Std. Dev. | Min | Max |
| :--- | :--- | :--- | :--- | :--- |
| CO₂ Emissions (metric tons/cap) | 5.82 | 4.67 | 0.12 | 22.45 |
| ICT Service Exports (%) | 8.94 | 9.52 | 0.31 | 58.23 |
| Control of Corruption | 0.42 | 1.02 | −1.67 | 2.47 |
| GDP per capita (US$) | 24,518 | 22,134 | 412 | 108,542 |
| Renewable Energy (%) | 18.42 | 16.78 | 0.02 | 78.45 |

---

# 3. Methodology

## 3.1 From Linear DML to Causal Forest

Traditional Double Machine Learning (Chernozhukov et al., 2018) estimates an *average* treatment effect θ. However, this approach masks heterogeneity. **Causal Forest DML** (Athey & Wager, 2019) extends this framework to estimate observation-specific effects:

$$ \tau(x) = \mathbb{E}[Y(1) - Y(0) | X = x] $$

where τ(x) is the Conditional Average Treatment Effect (CATE) for observation with characteristics x.

## 3.2 Causal Forest Implementation

We implement CausalForestDML (Athey & Wager, 2019) to estimate the Conditional Average Treatment Effect (CATE) function $\tau(x)$. Since the treatment is continuous, $\tau(x)$ represents the local marginal effect of a 1 percentage point increase in ICT service exports.

Configuration:
```
- n_estimators: 2,000 trees
- min_samples_leaf: 10
- First-stage models: XGBoost (to residualize Y and T)
- Controls: High-dimensional vector W including WGI, GDP, and energy/structural variables
```

*Note on Inference*: We report 95% confidence intervals for pointwise estimates. Standard errors are computed using the forest's variance estimates. We rely on the high-dimensional vector $W$ to capture confounding and heterogeneity; explicit country fixed effects are not included in the forest to allow learning from cross-sectional variation.

## 3.3 Heterogeneity Analyses

We assess heterogeneity in two ways:
1. **Linear Interaction Test (Phase 1)**: A pre-specified test of $T \times \text{Moderator}$ in a linear DML framework (cluster-robust SE).
2. **Forest-based CATE (Phase 2)**: Visualizing how the estimated $\tau(x)$ varies with observed characteristics. Correlations between $\tau(x)$ and moderators are descriptive.

---

# 4. Empirical Results

## 4.1 Heterogeneity Verification (Phase 1)

Before running the full Causal Forest, we verify heterogeneity exists using an interaction term model:

$$ Y = \beta_1 T + \beta_2 (T \times M) + g(W) + \epsilon $$

where M is log(GDP per capita). We also test institutional quality as a moderator.

### Table 3: Interaction Term Results
| Moderator | Coefficient | Estimate | SE | p-value |
|-----------|-------------|----------|-----|--------|
| log(GDP) | Main Effect (ICT) | −0.083 | 0.008 | <0.001 |
| log(GDP) | Interaction (ICT × log(GDP)) | **−0.035** | 0.004 | **<0.001** |
| Institution | Main Effect (ICT) | −0.014 | 0.009 | 0.123 |
| Institution | Interaction (ICT × Institution) | −0.013 | 0.008 | 0.121 |

The GDP interaction term is **highly significant** (p < 0.001), providing strong evidence of heterogeneity. The institutional quality interaction approaches significance (p = 0.121).

## 4.2 Causal Forest Results (Phase 2)

The full Causal Forest analysis reveals striking heterogeneity:

### Table 4: CATE Distribution (Descriptive)
| Statistic | Value |
|-----------|-------|
| Mean CATE | −0.020 |
| Median CATE | −0.015 |
| Std. Dev. | 0.020 |
| Minimum | −0.103 |
| Maximum | +0.036 |
| % Pointwise CIs excluding 0 | 25.3% (uncorrected) |

*Note: Significance flags are pointwise and do not correct for multiple testing or within-country dependence.*

### Table 5: Effect Direction (Point Estimates)
| Category | Count | Percentage |
|----------|-------|------------|
| Negative Point Estimate ($\tau < 0$) | 919 | 95.7% |
| Positive Point Estimate ($\tau > 0$) | 41 | 4.3% |

## 4.3 Sources of Heterogeneity

### Table 6: Correlation between CATE and Moderators
| Moderator | Correlation (r) | Interpretation |
|-----------|-----------------|----------------|
| GDP per capita (log) | −0.55 | **Strongest predictor** |
| Energy use per capita | −0.49 | High energy use → stronger reduction |
| Control of Corruption | −0.40 | Better institutions → stronger reduction |
| Renewable energy % | +0.27 | Higher renewables → weaker reduction |

*Note: Correlations are computed between estimated CATEs and moderators and are descriptive; they do not account for within-country dependence.*

## 4.4 Visualizing the Divide

### Figure 1: The Digital Decarbonization Divide (Institutional Quality)

![The Digital Decarbonization Divide](results/figures/divide_plot_institution.png)

*Note: Green points indicate pointwise estimates whose approximate 95% intervals exclude zero (uncorrected; not cluster-adjusted); gray points are the remainder. The blue line represents the linear trend.*

### Figure 2: Multi-Moderator Effects Panel

![Moderator Effects Panel](results/figures/moderator_effects_panel.png)

*Note: Four key moderators shown. GDP per capita shows the strongest moderation effect (r = −0.52).*

### Figure 3: Country-Level Heterogeneity

![Country Average CATE](results/figures/country_average_cate.png)

*Note: Switzerland (CHE), USA, and South Africa (ZAF) show the strongest reductions. Indonesia (IDN) and Pakistan (PAK) show minimal effects.*

---

# 5. Discussion

## 5.1 The Digital Decarbonization Divide

Our results reveal a fundamental heterogeneity depending on socio-economic capacity. The "Digital Decarbonization Divide" manifests along three dimensions:

1. **Development Divide**: Wealthier nations (higher GDP per capita) benefit significantly more from digital decarbonization. This is supported by our clustered interaction test (p < 0.001), suggesting that economic capacity is the primary driver of heterogeneity.

2. **Energy Structure Divide**: Counterintuitively, countries with *lower* renewable energy shares see stronger ICT-driven reductions. This suggests that ICT may substitute for carbon-intensive processes more effectively where the baseline is dirtier.

3. **Institutional Capacity (Suggestive)**: We observe a negative descriptive association between estimated CATEs and governance measures (e.g., control of corruption), but the clustered interaction-DML test does not provide strong statistical support for institutional moderation (p = 0.121). We therefore treat the institutional channel as suggestive and secondary to development-driven heterogeneity.

## 5.2 Mechanism Interpretation

We propose two non-mutually exclusive mechanisms:

**Enabling Conditions Hypothesis**: Strong institutions enable effective environmental regulation, ensuring that efficiency gains from ICT translate to emission reductions rather than increased consumption (rebound effects).

**Structural Transformation Hypothesis**: ICT development in wealthy economies represents a shift toward service-based, knowledge-intensive production that is inherently less carbon-intensive.

## 5.3 Comparison with Prior Literature

Our heterogeneous effects framework reconciles conflicting findings:
- Studies finding *negative* effects (Danish et al., 2018) likely sampled high-institution economies.
- Studies finding *positive* effects (Salahuddin & Alam, 2016) may have included observations where rebound effects dominate.
- The "null on average" finding masks genuine but conditional effects.

## 5.4 Policy Implications

**For Developed Economies**: Continue digital transformation as part of climate strategy. The evidence supports ICT as a decarbonization lever.

**For Developing Economies**: 
> ⚠️ **Policy Consideration**: Evidence suggests that digital transformation alone may not drive decarbonization in low-capacity settings. Countries with lower socio-economic capacity may need complementary efforts in:
> 1. Strengthening environmental regulation and enforcement
> 2. Investing in renewable energy infrastructure
> 3. Building institutional capacity for monitoring rebound effects

**For International Organizations**: Target digital development assistance as part of broader **capacity-building** packages (e.g., complementary investments in energy infrastructure and implementation capacity).

## 5.5 Limitations

- **Measurement**: ICT service exports capture only one dimension of digitalization.
- **Causal interpretation**: Despite the DML framework, unobserved confounders may remain.
- **External validity**: Results may not generalize to small economies not in our sample.

---

# 6. Conclusion

This paper introduces the concept of the "Digital Decarbonization Divide" and provides rigorous empirical evidence for its existence. Using Causal Forest DML on a balanced panel of 40 economies (N=960), we find that:

1. ICT's effect on CO₂ emissions is fundamentally **heterogeneous**.
2. **25.3%** of pointwise estimates have confidence intervals excluding zero (uncorrected).
3. Economic development is the strongest moderator in clustered interaction tests, while institutional quality appears descriptively correlated with heterogeneity.
4. The marginal effect ranges from −0.10 to +0.04 metric tons per capita.

Our findings challenge the assumption that digital transformation is universally beneficial for climate goals. Instead, we identify **conditional prerequisites**—socio-economic capacity—that appear to moderate whether ICT delivers a "green dividend."

**Policy Implications**:
- **For Developed Economies**: Continue leveraging ICT for efficiency, but monitor rebound effects in energy-intensive sectors (e.g., data centers).
- **For Developing Economies**: Results suggest that digital policies may be most effective when integrated with broader capacity-building strategies. Without sufficient socio-economic infrastructure, digital transformation alone may not automatically yield expected decarbonization benefits.

## Future Research

1. Extend to sector-level data to identify industry-specific digital effects.
2. Investigate time dynamics: Does the divide narrow as institutions improve?
3. Apply instrumental variable strategies to strengthen causal identification.
4. Examine specific ICT components (cloud computing, e-commerce, remote work).

---

# Data and Code Availability

All code and data are available in this repository:

| Component | Script |
|-----------|--------|
| Data Engineering | `scripts/solve_wdi_v4_expanded_zip.py` |
| Imputation | `scripts/impute_mice.py` |
| Variable Selection | `scripts/lasso_selection.py` |
| MVP Verification | `scripts/phase1_mvp_check.py` |
| **Causal Forest Analysis** | `scripts/phase2_causal_forest.py` |
| **Visualizations** | `scripts/phase3_visualizations.py` |
| Results | `results/causal_forest_cate.csv` |

---

# References

Athey, S. and Wager, S. (2019). Estimating treatment effects with causal forests: An application. *Observational Studies*, 5(2), 37–51.

Berkhout, F. and Hertin, J. (2000). De-materialising the economy or rematerialisation? *The Environmental Impact of Prosperous Societies*, 4, 12–26.

Chernozhukov, V., Chetverikov, D., Demirer, M., Duflo, E., Hansen, C., Newey, W., and Robins, J. (2018). Double/debiased machine learning for treatment and structural parameters. *The Econometrics Journal*, 21(1), C1–C68.

Danish, Zhang, B., Wang, B., and Wang, Z. (2018). Role of renewable energy and non-renewable energy consumption on EKC. *Journal of Cleaner Production*, 156, 855–864.

Gossart, C. (2015). Rebound effects and ICT: A review of the literature. In *ICT Innovations for Sustainability* (pp. 435–448). Springer.

Lange, S., Pohl, J., and Santarius, T. (2020). Digitalization and energy consumption. Does ICT reduce energy demand? *Ecological Economics*, 176, 106760.

Salahuddin, M. and Alam, K. (2016). ICT, electricity consumption and economic growth in OECD countries. *International Journal of Electrical Power & Energy Systems*, 76, 185–193.

World Bank. (2026). *World Development Indicators*. Washington, D.C.: The World Bank.
