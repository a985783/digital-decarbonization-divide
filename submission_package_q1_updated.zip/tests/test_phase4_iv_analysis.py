import pytest
import pandas as pd
import numpy as np
from unittest.mock import patch, MagicMock

def test_iv_logic_structure():
    try:
        from scripts import phase4_iv_analysis
    except ImportError:
        pytest.fail("Could not import scripts.phase4_iv_analysis")
    assert hasattr(phase4_iv_analysis, "run_iv_analysis")

@patch("scripts.phase4_iv_analysis.load_config")
@patch("scripts.phase4_iv_analysis.pd.read_csv")
@patch("scripts.phase4_iv_analysis.LinearDML")
@patch("scripts.phase4_iv_analysis.OrthoIV")
@patch("scripts.phase4_iv_analysis.prepare_analysis_data")
def test_iv_run(mock_prep, mock_ortho, mock_linear, mock_read_csv, mock_load_config):
    N = 20
    df_mock = pd.DataFrame({
        "country": ["A"]*10 + ["B"]*10,
        "year": list(range(2000, 2010)) * 2,
        "DCI": np.random.rand(20), 
        "CO2_per_capita": np.random.rand(20),
        "x1": np.random.rand(20),
        "w1": np.random.rand(20)
    })
    mock_read_csv.return_value = df_mock
    
    mock_load_config.return_value = {
        "outcome": "CO2_per_capita",
        "treatment_main": "DCI",
        "controls_W": ["w1"],
        "moderators_X": ["x1"],
        "groups": "country"
    }
    
    mock_prep.return_value = (
        np.zeros(N), np.zeros(N), np.zeros((N, 2)), np.zeros((N, 2)), df_mock
    )
    
    mock_est_iv = MagicMock()
    mock_ortho.return_value = mock_est_iv
    mock_est_iv.effect.return_value = np.zeros(N) 
    mock_est_iv.ate.return_value = 0.5
    mock_est_iv.ate_interval.return_value = (0.1, 0.9)
    
    mock_est_linear = MagicMock()
    mock_linear.return_value = mock_est_linear
    mock_est_linear.ate.return_value = 0.4
    
    from scripts import phase4_iv_analysis
    phase4_iv_analysis.run_iv_analysis()
    
    assert mock_est_iv.fit.called
    assert mock_est_linear.fit.called
