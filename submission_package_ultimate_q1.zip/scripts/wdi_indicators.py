def load_indicators(cfg):
    return cfg["wdi_indicators"]
